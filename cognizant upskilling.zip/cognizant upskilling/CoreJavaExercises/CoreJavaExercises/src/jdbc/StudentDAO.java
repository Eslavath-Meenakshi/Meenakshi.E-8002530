package jdbc;

import java.sql.*;

public class StudentDAO {
    
    static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
        		"jdbc:mysql://localhost:3306/studentdb", "root", "root1234");
    }
    
    static void insertStudent(int id, String name) {
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO students VALUES (?, ?)");
            ps.setInt(1, id);
            ps.setString(2, name);
            ps.executeUpdate();
            System.out.println("Student inserted: " + name);
            con.close();
        } catch(SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    static void updateStudent(int id, String newName) {
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(
                "UPDATE students SET name=? WHERE id=?");
            ps.setString(1, newName);
            ps.setInt(2, id);
            ps.executeUpdate();
            System.out.println("Student updated: ID " + id + " -> " + newName);
            con.close();
        } catch(SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    static void displayAll() {
        try {
            Connection con = getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM students");
            System.out.println("ID\tName");
            System.out.println("--------");
            while(rs.next()) {
                System.out.println(rs.getInt("id") + "\t" + rs.getString("name"));
            }
            con.close();
        } catch(SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    public static void main(String[] args) {
        System.out.println("Before insert:");
        displayAll();
        
        insertStudent(4, "Priya");
        insertStudent(5, "Mohan");
        
        System.out.println("\nAfter insert:");
        displayAll();
        
        updateStudent(4, "Priya Sharma");
        
        System.out.println("\nAfter update:");
        displayAll();
    }
}