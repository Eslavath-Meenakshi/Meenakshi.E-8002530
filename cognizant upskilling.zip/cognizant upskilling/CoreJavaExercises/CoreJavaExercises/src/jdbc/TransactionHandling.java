package jdbc;

import java.sql.*;

public class TransactionHandling {
    
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/studentdb";
        String user = "root";
        String password = "root1234";
        
        try {
            Connection con = DriverManager.getConnection(url, user, password);
            con.setAutoCommit(false);
            
            System.out.println("Before transfer:");
            displayAccounts(con);
            
            PreparedStatement debit = con.prepareStatement(
                "UPDATE accounts SET balance = balance - ? WHERE id = ?");
            debit.setDouble(1, 1000);
            debit.setInt(2, 1);
            debit.executeUpdate();
            
            PreparedStatement credit = con.prepareStatement(
                "UPDATE accounts SET balance = balance + ? WHERE id = ?");
            credit.setDouble(1, 1000);
            credit.setInt(2, 2);
            credit.executeUpdate();
            
            con.commit();
            System.out.println("\nTransfer successful!");
            
            System.out.println("\nAfter transfer:");
            displayAccounts(con);
            
            con.close();
            
        } catch(SQLException e) {
            System.out.println("Error! Rolling back: " + e.getMessage());
        }
    }
    
    static void displayAccounts(Connection con) throws SQLException {
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM accounts");
        System.out.println("ID\tName\tBalance");
        System.out.println("------------------");
        while(rs.next()) {
            System.out.println(rs.getInt("id") + "\t" + 
                             rs.getString("name") + "\t" + 
                             rs.getDouble("balance"));
        }
    }
}