package jdbc;

import java.sql.*;

public class BasicJDBCConnection {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/studentdb";
        String user = "root";
        String password = "root1234";
        
        try {
            Connection con = DriverManager.getConnection(url, user, password);
            System.out.println("Connected to database!");
            
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM students");
            
            System.out.println("ID\tName");
            System.out.println("--------");
            while(rs.next()) {
                System.out.println(rs.getInt("id") + "\t" + rs.getString("name"));
            }
            
            con.close();
            System.out.println("Connection closed!");
            
        } catch(SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}