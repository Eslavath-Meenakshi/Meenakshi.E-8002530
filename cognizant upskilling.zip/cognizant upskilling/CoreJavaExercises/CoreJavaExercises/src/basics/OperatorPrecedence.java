package basics;

public class OperatorPrecedence {
    public static void main(String[] args) {
        int a = 10 + 5 * 2;
        System.out.println("10 + 5 * 2 = " + a);
        System.out.println("(* first, then +) = 10 + 10 = 20");

        int b = (10 + 5) * 2;
        System.out.println("(10 + 5) * 2 = " + b);
        System.out.println("(+ first, then *) = 15 * 2 = 30");

        int c = 10 + 6 / 2 - 1;
        System.out.println("10 + 6 / 2 - 1 = " + c);
        System.out.println("(/ first) = 10 + 3 - 1 = 12");

        int d = 100 / 10 * 2 + 5 - 3;
        System.out.println("100 / 10 * 2 + 5 - 3 = " + d);
    }
}