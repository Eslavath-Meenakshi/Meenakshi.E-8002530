package basics;

public class TypeCastingExample {
    public static void main(String[] args) {
        // double to int
        double d = 9.99;
        int i = (int) d;
        System.out.println("Double to Int: " + d + " -> " + i);
        
        // int to double
        int num = 42;
        double result = (double) num;
        System.out.println("Int to Double: " + num + " -> " + result);
        
        // char to int
        char c = 'A';
        int ascii = (int) c;
        System.out.println("Char to Int: " + c + " -> " + ascii);
    }
}