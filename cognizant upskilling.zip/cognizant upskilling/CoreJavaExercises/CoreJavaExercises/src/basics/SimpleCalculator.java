/**
 * 
 */
package basics;
import java.util.Scanner;5

/**
 * 
 */
public class SimpleCalculator {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter first number: ");
        double a = sc.nextDouble();
        
        System.out.print("Enter second number: ");
        double b = sc.nextDouble();
        
        System.out.println("1. Add  2. Subtract  3. Multiply  4. Divide");
        System.out.print("Choose operation: ");
        int choice = sc.nextInt();
        
        if(choice == 1)
            System.out.println("Result: " + (a + b));
        else if(choice == 2)
            System.out.println("Result: " + (a - b));
        else if(choice == 3)
            System.out.println("Result: " + (a * b));
        else if(choice == 4)
            System.out.println("Result: " + (a / b));
        else
            System.out.println("Invalid choice!");
            
        sc.close();
    }
}
