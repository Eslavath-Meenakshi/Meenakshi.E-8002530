package reflection;

import java.lang.reflect.*;

public class ReflectionDemo {
    
    public void sayHello() {
        System.out.println("Hello from Reflection!");
    }
    
    public int addNumbers(int a, int b) {
        return a + b;
    }
    
    public static void main(String[] args) {
        try {
            Class<?> cls = Class.forName("reflection.ReflectionDemo");
            System.out.println("Class: " + cls.getName());
            
            System.out.println("\nAll Methods:");
            Method[] methods = cls.getDeclaredMethods();
            for(Method m : methods) {
                System.out.println("-> " + m.getName());
            }
            
            Object obj = cls.getDeclaredConstructor().newInstance();
            Method method = cls.getMethod("sayHello");
            method.invoke(obj);
            
        } catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}