package fileio;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileReading {
    public static void main(String[] args) {
        try {
            FileReader fr = new FileReader("output.txt");
            BufferedReader br = new BufferedReader(fr);
            
            String line;
            System.out.println("Contents of output.txt:");
            System.out.println("------------------------");
            
            while((line = br.readLine()) != null) {
                System.out.println(line);
            }
            
            br.close();
            System.out.println("------------------------");
            System.out.println("File read successfully!");
            
        } catch(IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}