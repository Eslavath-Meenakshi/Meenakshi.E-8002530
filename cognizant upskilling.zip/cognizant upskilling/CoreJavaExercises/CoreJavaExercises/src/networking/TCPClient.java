package networking;

import java.net.*;
import java.io.*;

public class TCPClient {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 5000);
            System.out.println("Connected to Server!");
            
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(
                new InputStreamReader(socket.getInputStream()));
            
            out.println("Hello from Client!");
            
            String response = in.readLine();
            System.out.println("Server says: " + response);
            
            socket.close();
        } catch(IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}