package strings;

import java.util.Scanner;

public class PalindromeChecker {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter a string: ");
        String str = sc.nextLine();
        
        String cleaned = str.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
        
        String reversed = new StringBuilder(cleaned).reverse().toString();
        
        if(cleaned.equals(reversed))
            System.out.println(str + " is a Palindrome!");
        else
            System.out.println(str + " is NOT a Palindrome!");
            
        sc.close();
    }
}