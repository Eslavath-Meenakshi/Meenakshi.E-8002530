package oop;

interface Playable {
    void play();
}

class Guitar implements Playable {
    @Override
    public void play() {
        System.out.println("Playing Guitar: Strum strum!");
    }
}

class Piano implements Playable {
    @Override
    public void play() {
        System.out.println("Playing Piano: Tink tink!");
    }
}

public class InterfaceImplementation {
    public static void main(String[] args) {
        Playable guitar = new Guitar();
        guitar.play();
        
        Playable piano = new Piano();
        piano.play();
    }
}