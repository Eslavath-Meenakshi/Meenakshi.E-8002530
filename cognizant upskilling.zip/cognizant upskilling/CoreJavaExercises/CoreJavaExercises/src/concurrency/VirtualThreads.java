package concurrency;

public class VirtualThreads {
    public static void main(String[] args) {
        System.out.println("Starting 10 Virtual Threads...");
        
        long startTime = System.currentTimeMillis();
        
        Thread[] threads = new Thread[10];
        
        for(int i = 1; i <= 10; i++) {
            final int threadNum = i;
            threads[threadNum-1] = Thread.ofVirtual().start(() -> {
                System.out.println("Virtual Thread " + threadNum + " is running!");
                try {
                    Thread.sleep(100);
                } catch(InterruptedException e) {
                    e.printStackTrace();
                }
            });
        }
        
        for(Thread t : threads) {
            try {
                t.join();
            } catch(InterruptedException e) {
                e.printStackTrace();
            }
        }
        
        long endTime = System.currentTimeMillis();
        System.out.println("\nAll Virtual Threads Done!");
        System.out.println("Time taken: " + (endTime - startTime) + "ms");
    }
}