package concurrency;

import java.util.concurrent.*;
import java.util.ArrayList;
import java.util.List;

public class ExecutorServiceCallable {
    public static void main(String[] args) {
        ExecutorService executor = Executors.newFixedThreadPool(3);
        
        List<Future<Integer>> futures = new ArrayList<>();
        
        for(int i = 1; i <= 5; i++) {
            final int taskNum = i;
            Callable<Integer> task = () -> {
                System.out.println("Task " + taskNum + " is running!");
                Thread.sleep(500);
                return taskNum * taskNum;
            };
            futures.add(executor.submit(task));
        }
        
        System.out.println("\nResults:");
        for(int i = 0; i < futures.size(); i++) {
            try {
                int result = futures.get(i).get();
                System.out.println("Task " + (i+1) + " result: " + result);
            } catch(Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        
        executor.shutdown();
        System.out.println("\nAll tasks completed!");
    }
}