package control;

import java.util.Scanner;
import java.util.Random;

public class NumberGuessingGame {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();
        
        int secret = rand.nextInt(100) + 1;
        int guess = 0;
        int attempts = 0;
        
        System.out.println("Guess the number between 1 and 100!");
        
        while(guess != secret) {
            System.out.print("Enter your guess: ");
            guess = sc.nextInt();
            attempts++;
            
            if(guess < secret)
                System.out.println("Too Low! Try again.");
            else if(guess > secret)
                System.out.println("Too High! Try again.");
            else
                System.out.println("Correct! You got it in " + attempts + " attempts!");
        }
        
        sc.close();
    }
}