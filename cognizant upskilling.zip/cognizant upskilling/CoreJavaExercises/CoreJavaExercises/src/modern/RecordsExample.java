package modern;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

record Person(String name, int age) {}

public class RecordsExample {
    public static void main(String[] args) {
        Person p1 = new Person("Ravi", 25);
        Person p2 = new Person("Sita", 17);
        Person p3 = new Person("Arjun", 30);
        Person p4 = new Person("Priya", 15);
        
        System.out.println("All Persons:");
        System.out.println(p1);
        System.out.println(p2);
        System.out.println(p3);
        System.out.println(p4);
        
        List<Person> persons = Arrays.asList(p1, p2, p3, p4);
        
        System.out.println("\nPersons aged 18 and above:");
        List<Person> adults = persons.stream()
                .filter(p -> p.age() >= 18)
                .collect(Collectors.toList());
        adults.forEach(System.out::println);
    }
}