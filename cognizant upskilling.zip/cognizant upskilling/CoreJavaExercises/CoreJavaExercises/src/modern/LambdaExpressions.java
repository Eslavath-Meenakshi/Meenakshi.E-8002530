package modern;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LambdaExpressions {
    public static void main(String[] args) {
        List<String> names = new ArrayList<>();
        names.add("Ravi");
        names.add("Arjun");
        names.add("Sita");
        names.add("Priya");
        names.add("Mohan");
        
        System.out.println("Before sorting:");
        for(String name : names) {
            System.out.println(name);
        }
        
        Collections.sort(names, (a, b) -> a.compareTo(b));
        
        System.out.println("\nAfter sorting:");
        for(String name : names) {
            System.out.println(name);
        }
    }
}