package modern;

public class PatternMatchingSwitch {
    
    static void checkType(Object obj) {
        String result = switch(obj) {
            case Integer i -> "Integer: " + i;
            case String s -> "String: " + s;
            case Double d -> "Double: " + d;
            case Boolean b -> "Boolean: " + b;
            default -> "Unknown type: " + obj;
        };
        System.out.println(result);
    }
    
    public static void main(String[] args) {
        checkType(42);
        checkType("Hello Java!");
        checkType(3.14);
        checkType(true);
        checkType('A');
    }
}