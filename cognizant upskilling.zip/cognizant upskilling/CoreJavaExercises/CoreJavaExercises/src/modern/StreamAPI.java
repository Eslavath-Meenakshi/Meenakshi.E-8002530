package modern;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamAPI {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
        
        System.out.println("All numbers:");
        numbers.stream().forEach(n -> System.out.print(n + " "));
        
        System.out.println("\n\nEven numbers:");
        List<Integer> evens = numbers.stream()
                .filter(n -> n % 2 == 0)
                .collect(Collectors.toList());
        evens.forEach(n -> System.out.print(n + " "));
        
        System.out.println("\n\nSquares of even numbers:");
        numbers.stream()
                .filter(n -> n % 2 == 0)
                .map(n -> n * n)
                .forEach(n -> System.out.print(n + " "));
        
        int sum = numbers.stream()
                .reduce(0, Integer::sum);
        System.out.println("\n\nSum of all numbers: " + sum);
    }
}