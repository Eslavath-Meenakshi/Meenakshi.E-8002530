// Log message in Console
console.log("Welcome to the Community Portal");

// Alert when page is fully loaded
window.onload = function () {
    alert("Page is fully loaded!");
};