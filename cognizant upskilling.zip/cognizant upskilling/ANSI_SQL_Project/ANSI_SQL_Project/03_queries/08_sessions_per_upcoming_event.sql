-- Exercise 8: Sessions per Upcoming Event
USE eventdb;

SELECT 
    e.title,
    e.city,
    e.start_date,
    COUNT(s.session_id) as total_sessions
FROM Events e
LEFT JOIN Sessions s ON e.event_id = s.event_id
WHERE e.status = 'upcoming'
GROUP BY e.event_id, e.title, e.city, e.start_date
ORDER BY total_sessions DESC;