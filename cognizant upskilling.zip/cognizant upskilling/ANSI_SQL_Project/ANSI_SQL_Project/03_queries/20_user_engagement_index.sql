-- Exercise 20: User Engagement Index
USE eventdb;

SELECT 
    u.full_name,
    COUNT(DISTINCT r.event_id) as events_attended,
    COUNT(DISTINCT f.feedback_id) as feedbacks_submitted
FROM Users u
LEFT JOIN Registrations r ON u.user_id = r.user_id
LEFT JOIN Feedback f ON u.user_id = f.user_id
GROUP BY u.user_id, u.full_name
ORDER BY events_attended DESC, feedbacks_submitted DESC;