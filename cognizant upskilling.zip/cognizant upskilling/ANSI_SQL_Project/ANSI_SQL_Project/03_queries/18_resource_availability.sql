-- Exercise 18: Resource Availability Check
USE eventdb;

SELECT 
    e.event_id,
    e.title,
    e.city,
    e.status
FROM Events e
WHERE e.event_id NOT IN (
    SELECT DISTINCT event_id 
    FROM Resources
)
ORDER BY e.event_id;