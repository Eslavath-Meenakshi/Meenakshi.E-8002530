-- Exercise 4: Peak Session Hours
USE eventdb;

SELECT 
    e.title,
    COUNT(s.session_id) as session_count
FROM Events e
JOIN Sessions s ON e.event_id = s.event_id
WHERE HOUR(s.start_time) >= 10 
AND HOUR(s.start_time) < 12
GROUP BY e.event_id, e.title
ORDER BY session_count DESC;