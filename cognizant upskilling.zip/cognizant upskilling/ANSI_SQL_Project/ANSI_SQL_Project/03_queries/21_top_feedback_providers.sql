-- Exercise 21: Top Feedback Providers
USE eventdb;

SELECT 
    u.full_name,
    COUNT(f.feedback_id) as total_feedback
FROM Users u
JOIN Feedback f ON u.user_id = f.user_id
GROUP BY u.user_id, u.full_name
ORDER BY total_feedback DESC
LIMIT 5;