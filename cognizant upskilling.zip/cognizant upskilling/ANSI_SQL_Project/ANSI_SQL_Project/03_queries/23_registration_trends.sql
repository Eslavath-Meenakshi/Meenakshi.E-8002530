-- Exercise 23: Registration Trends
USE eventdb;

SELECT 
    DATE_FORMAT(registration_date, '%Y-%m') as month,
    COUNT(registration_id) as total_registrations
FROM Registrations
WHERE registration_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
GROUP BY DATE_FORMAT(registration_date, '%Y-%m')
ORDER BY month ASC;