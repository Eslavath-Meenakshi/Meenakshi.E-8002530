-- Exercise 12: Event with Maximum Sessions
USE eventdb;

SELECT 
    e.title,
    COUNT(s.session_id) as total_sessions
FROM Events e
JOIN Sessions s ON e.event_id = s.event_id
GROUP BY e.event_id, e.title
HAVING COUNT(s.session_id) = (
    SELECT MAX(session_count)
    FROM (
        SELECT COUNT(session_id) as session_count
        FROM Sessions
        GROUP BY event_id
    ) as counts
)
ORDER BY total_sessions DESC;