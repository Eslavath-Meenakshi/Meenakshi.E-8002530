-- Exercise 2: Top Rated Events
USE eventdb;

SELECT 
    e.title,
    AVG(f.rating) as average_rating,
    COUNT(f.feedback_id) as total_feedback
FROM Events e
JOIN Feedback f ON e.event_id = f.event_id
GROUP BY e.event_id, e.title
HAVING COUNT(f.feedback_id) >= 10
ORDER BY average_rating DESC;