-- Exercise 17: Multi Session Speakers
USE eventdb;

SELECT 
    speaker_name,
    COUNT(session_id) as total_sessions
FROM Sessions
GROUP BY speaker_name
HAVING COUNT(session_id) > 1
ORDER BY total_sessions DESC;