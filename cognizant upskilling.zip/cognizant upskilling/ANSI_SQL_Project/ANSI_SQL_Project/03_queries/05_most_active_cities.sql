-- Exercise 5: Most Active Cities
USE eventdb;

SELECT 
    e.city,
    COUNT(DISTINCT r.user_id) as total_registrations
FROM Events e
JOIN Registrations r ON e.event_id = r.event_id
GROUP BY e.city
ORDER BY total_registrations DESC
LIMIT 5;