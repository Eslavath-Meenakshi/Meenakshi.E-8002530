-- Exercise 16: Unregistered Active Users
USE eventdb;

SELECT 
    u.user_id,
    u.full_name,
    u.email,
    u.registration_date
FROM Users u
WHERE u.registration_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
AND u.user_id NOT IN (
    SELECT DISTINCT user_id 
    FROM Registrations
);