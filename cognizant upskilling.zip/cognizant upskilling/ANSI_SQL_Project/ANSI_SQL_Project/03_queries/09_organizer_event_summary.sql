-- Exercise 9: Organizer Event Summary
USE eventdb;

SELECT 
    u.full_name as organizer_name,
    e.status,
    COUNT(e.event_id) as total_events
FROM Users u
JOIN Events e ON u.user_id = e.organizer_id
GROUP BY u.user_id, u.full_name, e.status
ORDER BY u.full_name, e.status;