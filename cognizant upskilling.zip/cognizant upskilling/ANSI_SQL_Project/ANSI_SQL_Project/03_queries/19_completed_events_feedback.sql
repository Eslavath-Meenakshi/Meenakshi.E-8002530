-- Exercise 19: Completed Events with Feedback Summary
USE eventdb;

SELECT 
    e.title,
    e.city,
    COUNT(DISTINCT r.registration_id) as total_registrations,
    ROUND(AVG(f.rating), 2) as average_rating,
    COUNT(DISTINCT f.feedback_id) as total_feedback
FROM Events e
LEFT JOIN Registrations r ON e.event_id = r.event_id
LEFT JOIN Feedback f ON e.event_id = f.event_id
WHERE e.status = 'completed'
GROUP BY e.event_id, e.title, e.city
ORDER BY average_rating DESC;