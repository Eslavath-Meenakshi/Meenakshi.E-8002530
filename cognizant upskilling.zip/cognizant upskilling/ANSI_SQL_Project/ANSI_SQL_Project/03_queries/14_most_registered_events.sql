-- Exercise 14: Most Registered Events
USE eventdb;

SELECT 
    e.title,
    COUNT(r.registration_id) as total_registrations
FROM Events e
JOIN Registrations r ON e.event_id = r.event_id
GROUP BY e.event_id, e.title
ORDER BY total_registrations DESC
LIMIT 3;