-- Exercise 1: User Upcoming Events
USE eventdb;

SELECT 
    u.full_name,
    e.title,
    e.city,
    e.start_date
FROM Users u
JOIN Registrations r ON u.user_id = r.user_id
JOIN Events e ON r.event_id = e.event_id
WHERE e.status = 'upcoming'
AND e.city = u.city
ORDER BY e.start_date;