-- Exercise 13: Average Rating per City
USE eventdb;

SELECT 
    e.city,
    ROUND(AVG(f.rating), 2) as average_rating,
    COUNT(f.feedback_id) as total_feedback
FROM Events e
JOIN Feedback f ON e.event_id = f.event_id
GROUP BY e.city
ORDER BY average_rating DESC;