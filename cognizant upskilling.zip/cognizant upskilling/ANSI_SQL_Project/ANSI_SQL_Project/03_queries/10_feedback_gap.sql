-- Exercise 10: Feedback Gap
USE eventdb;

SELECT 
    e.title,
    COUNT(r.registration_id) as total_registrations
FROM Events e
JOIN Registrations r ON e.event_id = r.event_id
WHERE e.event_id NOT IN (
    SELECT DISTINCT event_id 
    FROM Feedback
)
GROUP BY e.event_id, e.title
ORDER BY total_registrations DESC;